Assignment #2
CPSC 351 section 01
Language: C++

Names:
Emily Chiang		// Section 02
Christopher Randin      // Section 01
Mark Martene            // Section 01
Reza Nikoopour          // Section 01

Member Contribution:
Emily: Got working on retrieving message using message queues.
Chris: Got working on sending messaes using message queues.
Mark: Helped with code formatting and presenting code to be consistent.
Reza: Helped with troubleshooting problems and understanding of IPC.

Execution Instructions:
	Be in the directory for this program. Run make.
	sender is ./sender
	receive is ./recv

	You may need to use sudo to run the above commands.
	To run the sender program
		sudo ./sender keyfile.txt

	To run the receiver program
		sudo ./recv
	CTRL+C while the recv file is running 

Extra Credit:
N/A

Resulting program transfers desginated file to "recvfile".

