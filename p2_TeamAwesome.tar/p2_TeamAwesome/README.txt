Assignment #2
CPSC 351 section 01
Language: C++

Names:
Emily Chiang		// Section 02
Christopher Randin
Mark Martene
Reza Nikoopour

Execution Instructions:
	Be in the directory for this program. Run make.
	sender is ./sender
	receive is ./recv

	You may need to use sudo to run the above commands.
	To run the sender program
		sudo ./sender keyfile.txt

	To run the receiver program
		sudo ./recv
	CTRL+C while the recv file is running 

Extra Credit

Resulting program transfers desginated file to "recvfile".
